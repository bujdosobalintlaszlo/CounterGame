﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CountingGame
{
    public partial class Form1 : Form
    {
        private Dictionary<string, Action> buttonFunctions;
        private int nehezseg;
        private Random random = new Random();
        private List<Button> gombok = new List<Button>();
        private int aktualisIndex = 1;
        private int pontszam = 0;

        public Form1()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            EventDictionaryba();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FokepernyoGen(sender,e);
        }

        private void FokepernyoGen(object o , EventArgs e)
        {
            this.Controls.Clear();
            aktualisIndex = 1;
            pontszam = 0;
            FlowLayoutPanel FNehezseg = FlowPanelGeneral(FlowDirection.LeftToRight);
            AddButtonsToPanel(FNehezseg, 3, "Könnyű mód", "Közepes mód", "Nehéz mód");
            FlowLayoutPanel FInditas = FlowPanelGeneral(FlowDirection.TopDown);
            Button BStart = GombGeneralas("Indítás", 50, 100);
            FInditas.Controls.Add(BStart);
            FlowLayoutPanel FMain = FlowPanelGeneral(FlowDirection.TopDown);
            FNehezseg.Anchor = AnchorStyles.None;
            FInditas.Anchor = AnchorStyles.None;
            FMain.Anchor = AnchorStyles.None;
            this.Controls.Add(FMain);
            FMain.Controls.Add(FNehezseg);
            FMain.Controls.Add(FInditas);
            FMain.Location = new Point((this.ClientSize.Width - FMain.Width) / 2, (this.ClientSize.Height - FMain.Height) / 2);
            EventetGombhozAdNehezsegek(FNehezseg);
            EventetGombhozAdInditas(BStart, "Indítás");
        }

        private FlowLayoutPanel FlowPanelGeneral(FlowDirection direction)
        {
            FlowLayoutPanel panel = new FlowLayoutPanel();
            panel.FlowDirection = direction;
            panel.AutoSize = true;
            panel.Dock = DockStyle.None;
            panel.Anchor = AnchorStyles.None;
            return panel;
        }

        private void AddButtonsToPanel(FlowLayoutPanel panel, int count, params string[] buttonTexts)
        {
            for (int i = 0; i < count && i < buttonTexts.Length; i++)
            {
                Button button = GombGeneralas(buttonTexts[i], 50, 100);
                button.Name = buttonTexts[i];
                panel.Controls.Add(button);
            }
        }

        private Button GombGeneralas(string text, int magassag, int szelesseg)
        {
            Button button = new Button();
            button.Text = text;
            button.Height = magassag;
            button.Width = szelesseg;
            button.Anchor = AnchorStyles.None;
            button.Name = text;
            return button;
        }

        private void EventDictionaryba()
        {
            buttonFunctions = new Dictionary<string, Action>
            {
                { "Könnyű mód", Konnyu },
                { "Közepes mód", Kozepes },
                { "Nehéz mód", Nehez },
                { "Indítás", Inditas }
            };
        }

        private void EventetGombhozAdNehezsegek(FlowLayoutPanel panel)
        {
            foreach (Button button in panel.Controls)
            {
                if (buttonFunctions.TryGetValue(button.Text, out Action function))
                {
                    button.Click += (sender, e) => function();
                }
            }
        }

        private void EventetGombhozAdInditas(Button button, string buttonText)
        {
            if (buttonFunctions.TryGetValue(buttonText, out Action function))
            {
                button.Click += (sender, e) => function();
            }
            button.Enabled = false;
        }

        private void Konnyu()
        {
            nehezseg = 0;
            InditasGombEngedelyezese();
        }

        private void Kozepes()
        {
            nehezseg = 1;
            InditasGombEngedelyezese();
        }

        private void Nehez()
        {
            nehezseg = 2;
            InditasGombEngedelyezese();
        }

        private void InditasGombEngedelyezese()
        {
            Button inditasGomb = (Button)Controls.Find("Indítás", true).FirstOrDefault(b => b.Name == "Indítás");
            if (inditasGomb != null && !inditasGomb.Enabled)
            {
                inditasGomb.Enabled = true;
            }
        }

        private void Inditas()
        {
            this.Controls.Clear();
            Button backgroundButton = new Button();
            backgroundButton.Text = "Indítás";
            backgroundButton.Font = new Font(backgroundButton.Font.FontFamily, 40);
            backgroundButton.BackColor = Color.Transparent;
            backgroundButton.FlatStyle = FlatStyle.Flat;
            backgroundButton.FlatAppearance.BorderSize = 0;
            backgroundButton.Dock = DockStyle.Fill;
            backgroundButton.Click += KezddElJatekot;
            this.Controls.Add(backgroundButton);
        }

        private void KezddElJatekot(object o, EventArgs e)
        {
            if (nehezseg == 0)
            {
                this.Controls.Clear();
                KonnyuGen();
            }
            else if (nehezseg == 1)
            {
                this.Controls.Clear();
                KozepesGen();
            }
            else if (nehezseg == 2)
            {
                this.Controls.Clear();
                NehezGen();
            }
        }

        private Button GombGeneralasHover(string text, int magassag, int szelesseg, int uniqueID)
        {
            Button button = new Button();
            button.Text = text;
            button.Height = magassag;
            button.Width = szelesseg;
            button.Anchor = AnchorStyles.None;
            button.Name = text;
            button.MouseEnter += EltuntetHaJo;
            button.Tag = uniqueID;
            return button;
        }


        private void KonnyuGen()
        {
            int buttonWidth = 50;
            int buttonHeight = 50;
            int minDistance = 30;

            for (int i = 1; i <= 20; i++)
            {
                Button gomb = GombGeneralasHover(i.ToString(), buttonWidth, buttonHeight, i);
                int x, y;
                do
                {
                    x = random.Next(Math.Max(0, this.ClientSize.Width - buttonWidth + 1));
                    y = random.Next(Math.Max(0, this.ClientSize.Height - buttonHeight + 1));
                } while (EllenorzottHely(x, y, buttonWidth, buttonHeight, minDistance) ||
                         x + buttonWidth > this.ClientSize.Width - minDistance ||
                         y + buttonHeight > this.ClientSize.Height - minDistance);

                gomb.Location = new Point(x, y);
                this.Controls.Add(gomb);
                gombok.Add(gomb);
            }
        }


        private void KozepesGen()
        {
            int buttonWidth = 40;
            int buttonHeight = 40;
            int minDistance = 10;

            for (int i = 1; i <= 40; i++)
            {
                Button gomb = GombGeneralasHover(i.ToString(), buttonWidth, buttonHeight, i);
                int x, y;
                do
                {
                    x = random.Next(Math.Max(0, this.ClientSize.Width - buttonWidth + 1));
                    y = random.Next(Math.Max(0, this.ClientSize.Height - buttonHeight + 1));
                } while (EllenorzottHely(x, y, buttonWidth, buttonHeight, minDistance) ||
                         x + buttonWidth > this.ClientSize.Width - minDistance ||
                         y + buttonHeight > this.ClientSize.Height - minDistance);

                gomb.Location = new Point(x, y);
                this.Controls.Add(gomb);
                gombok.Add(gomb);
            }
        }

        private void NehezGen()
        {
            int buttonWidth = 30;
            int buttonHeight = 30;
            int minDistance = 5;

            for (int i = 1; i <= 50; i++)
            {
                Button gomb = GombGeneralasHover(i.ToString(), buttonWidth, buttonHeight, i);
                int x, y;
                do
                {
                    x = random.Next(Math.Max(0, this.ClientSize.Width - buttonWidth + 1));
                    y = random.Next(Math.Max(0, this.ClientSize.Height - buttonHeight + 1));
                } while (EllenorzottHely(x, y, buttonWidth, buttonHeight, minDistance) ||
                         x + buttonWidth > this.ClientSize.Width - minDistance ||
                         y + buttonHeight > this.ClientSize.Height - minDistance);

                gomb.Location = new Point(x, y);
                this.Controls.Add(gomb);
                gombok.Add(gomb);
            }
        }

        private async void EltuntetHaJo(object sender, EventArgs e)
        {
            Button aktualisGomb = (Button)sender;
            int expectedIndex = (int)aktualisGomb.Tag;
            if (expectedIndex == aktualisIndex)
            {

                if (aktualisIndex == gombok.Count)
                {
                    this.Controls.Clear();
                    Button BVege = new Button();
                    BVege.Height = this.ClientSize.Height;
                    BVege.Width = this.ClientSize.Width;
                    BVege.Font = new Font(BVege.Font.FontFamily, 40);
                    BVege.BackColor = Color.Transparent;
                    BVege.FlatStyle = FlatStyle.Flat;
                    BVege.FlatAppearance.BorderSize = 0;
                    BVege.Dock = DockStyle.Fill;
                    BVege.Text = $"Pontszám: {pontszam}";
                    BVege.Click += FokepernyoGen;
                    this.Controls.Add(BVege);
                }
                else
                {
                    aktualisIndex++;
                    aktualisGomb.Visible = false;
                    pontszam += 5;
                }
            }
            else
            {
                aktualisGomb.BackColor = Color.Red;
                await Task.Delay(1000);
                aktualisGomb.BackColor = SystemColors.Control;
                if (pontszam > 2)
                {
                    pontszam -= 2;
                }
            }
        }

        private bool EllenorzottHely(int x, int y, int width, int height, int minDistance)
        {
            foreach (Control control in this.Controls)
            {
                if (control is Button)
                {
                    Rectangle existingButtonRect = new Rectangle(control.Location, control.Size);
                    Rectangle newButtonRect = new Rectangle(x, y, width, height);

                    if (existingButtonRect.IntersectsWith(newButtonRect) ||
                        Math.Abs(x - control.Location.X) < minDistance ||
                        Math.Abs(y - control.Location.Y) < minDistance)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
    }
}
